#ifndef HELPERS_H
#define HELPERS_H

#define BUF_SIZE 1024

int read_data();

#endif
